/* file:	mouse_server.cpp - a simple vrpn_Mouse server application
 * author:	Mike Weiblen mew@mew.cx 2004-01-14
 * copyright:	(C) 2003,2004 Michael Weiblen
 * license:	Released to the Public Domain
 * depends:	gpm 1.19.6, VRPN 06_04
 * tested on:	Linux w/ gcc 2.95.4
 * references:  http://mew.cx/ http://vrpn.org/
 *
 * A simple standalone server app for the vrpn_Mouse device.
*/

#include <stdio.h>

#include "vrpn_Connection.h"
#include "vrpn_Mouse.h"

const char* const DEVICE = "Mouse0";

int main( int argc, char *argv[] )
{
    vrpn_Connection* cxn = new vrpn_Synchronized_Connection;

    vrpn_Mouse* mouse;
    try {
	mouse = new vrpn_Mouse( DEVICE, cxn );
    }
    catch (...) {
	fprintf( stderr, "could not create vrpn_Mouse \"%s\"\n", DEVICE );
	fprintf( stderr, "- Is the GPM server running?\n" );
	fprintf( stderr, "- Are you running on a linux console (not an xterm)?\n" );
	exit( 1 );
    }

    printf( "created vrpn_Mouse as \"%s\"\n", DEVICE );

    while( 1 )
    {
	mouse->mainloop();
	cxn->mainloop();
	vrpn_SleepMsecs(1);     // so as not to eat the cpu
    }
    exit( 0 );
}

/*EOF*/
