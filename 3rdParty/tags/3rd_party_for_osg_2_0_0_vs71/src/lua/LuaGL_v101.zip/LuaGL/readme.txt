LuaGL v1.01 - an OpenGL binding for Lua 5.0
2003(c) Fabio Guerra, Cleyde Marlyse
www.luagl.sourceforge.net